import { getData } from "../utils/data.js";
import { photographerFactory } from "../factories/photographer.js";
import { mediaFactory } from "../factories/media.js";
import { initModalContact } from "../utils/contactForm.js";
import { initModalLightBox } from "../utils/modalLightbox.js";
import { initStatsPhotographer } from "../utils/statsPhotographer.js";
import { initSortbyMenu, sortByDate, sortByTitle, sortByPopularity } from "../utils/sortbyMenu.js";

async function init() {
  const $profilSection = document.querySelector(".profil");
  const $galerySection = document.querySelector(".galery-section");

  // Get data API
  const { photographers, media } = await getData();

  // Get id URL
  const urlParam = new URL(document.location).searchParams;
  let photographerId = parseInt(urlParam.get("id"));

  try {
    // Search Photographer
    const selectedPhotographer = photographers.find(photographer => photographer.id === photographerId);

    // Check if selectedPhotographer exists, else throw an error
    if (!selectedPhotographer) {
      throw new Error("Photographer not found");
    }

    // DOM Photographer Profil
    const photographerModel = photographerFactory(selectedPhotographer);
    const photographerName = photographerModel.getName();
    const photographerProfilDOM = photographerModel.createPhotographerProfileDOM();
    $profilSection.appendChild(photographerProfilDOM);

    // Prepare the contact modal and add the event listeners
    initModalContact(photographerName);

    // Filter media by photographerId
    const photographerMedia = media.filter(mediaItem => mediaItem.photographerId === photographerId);

    if (photographerMedia.length > 0) {
      let totalLikes = photographerMedia.reduce((acc, item) => acc + item.likes, 0);

      const collectionMediaModel = {};
      photographerMedia.forEach(mediaItem => {
        collectionMediaModel[mediaItem.id] = mediaFactory(mediaItem, photographerName);
      });

      renderGallery(collectionMediaModel, $galerySection);
      initModalLightBox(photographerMedia, photographerName);
      handleSortChange("optionPopularity", collectionMediaModel, $galerySection);
      initSortbyMenu(selectedOption => handleSortChange(selectedOption, collectionMediaModel, $galerySection));
      initStatsPhotographer(totalLikes, photographerModel.getPrice(), collectionMediaModel);
    }
  } catch (error) {
    console.error(error.message);
  }
}

// Render gallery function
function renderGallery(collectionMediaModel, $container) {
  $container.innerHTML = ""; // Clear existing content
  console.log("test");

  for (const mediaItemId in collectionMediaModel) {
    const mediaCardDOM = collectionMediaModel[mediaItemId].createMediaCardDOM();
    $container.appendChild(mediaCardDOM);
  }
}

// Sort change handler
function handleSortChange(selectedOption, collectionMediaModel, $galerySection) {
  const sortedMediaModels = Object.values(collectionMediaModel);

  // Select the appropriate sorting function based on the selected option
  let sortFunction;
  switch (selectedOption) {
    case "optionDate":
      sortFunction = sortByDate;
      break;
    case "optionTitle":
      sortFunction = sortByTitle;
      break;
    case "optionPopularity":
      sortFunction = sortByPopularity;
      break;
  }

  sortedMediaModels.sort(sortFunction);
  renderGallery(sortedMediaModels, $galerySection);
}

init();
